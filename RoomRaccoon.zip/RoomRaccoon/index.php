<?php

require 'webroot' . DIRECTORY_SEPARATOR . 'index.php';
